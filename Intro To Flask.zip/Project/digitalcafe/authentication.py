import database as db

def login(username, password):
    # Default response is fields are both missing
    is_valid_login = False
    user=None

    # c. Incomplete login data is passed (missing username or password or both)
    if (username != '' or password != ''):
        temp_user = db.get_user(username)
        # a. Username entered is invalid
        if (temp_user == None):
            is_valid_login = False
        else:
            # b. Password
            if(temp_user["password"]==password):
                is_valid_login = "authorized"
                user={"username":username,
                    "first_name":temp_user["first_name"],
                    "last_name":temp_user["last_name"]}
            else:
                is_valid_login = False
            
    return is_valid_login, user
